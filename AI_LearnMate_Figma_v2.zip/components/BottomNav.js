import React from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function BottomNav(){
  return (
    <View style={styles.wrap}>
      <TouchableOpacity style={styles.btn}><Ionicons name="home" size={22} color="#fff" /></TouchableOpacity>
      <TouchableOpacity style={styles.btn}><Ionicons name="book" size={22} color="#fff" /></TouchableOpacity>
      <TouchableOpacity style={[styles.btn, styles.center]}><Ionicons name="add-circle" size={38} color="#fff" /></TouchableOpacity>
      <TouchableOpacity style={styles.btn}><Ionicons name="search" size={22} color="#fff" /></TouchableOpacity>
      <TouchableOpacity style={styles.btn}><Ionicons name="person" size={22} color="#fff" /></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap:{height:62, backgroundColor:'#6B5DD3', flexDirection:'row', justifyContent:'space-around', alignItems:'center', paddingHorizontal:6},
  btn:{padding:6},
  center:{marginTop:-8}
});
